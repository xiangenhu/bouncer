//
//  AppDelegate.h
//  SKOPlayer
//
//  Created by shfrc10401 on 2015-05-10.
//  Copyright (c) 2015 Media Semantics, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

