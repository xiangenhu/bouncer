//
//  ViewController.h
//  SKOPlayer
//
//  Created by shfrc10401 on 2015-05-10.
//  Copyright (c) 2015 Media Semantics, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    
    IBOutlet UIWebView *webView;
    
}
@end

