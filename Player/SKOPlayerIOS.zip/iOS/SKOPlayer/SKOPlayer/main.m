//
//  main.m
//  SKOPlayer
//
//  Created by shfrc10401 on 2015-05-10.
//  Copyright (c) 2015 Media Semantics, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
