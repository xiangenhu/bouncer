//
//  ViewController.m
//  SKOPlayer
//
//  Created by shfrc10401 on 2015-05-10.
//  Copyright (c) 2015 Media Semantics, Inc. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURL *url = [NSURL URLWithString:@"http://www.mediasemantics.com/test/player/Player.html"];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
